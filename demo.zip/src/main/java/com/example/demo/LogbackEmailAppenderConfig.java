package com.example.demo;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Configuration class to initialize the EmailErrorAppender with Spring ApplicationContext.
 *
 * <p><b>Updates in v3.0.0:</b>
 * <ul>
 *   <li>Injects MeterRegistry for observability.</li>
 *   <li>Reads configuration from application.properties (queue size, circuit breaker).</li>
 * </ul>
 *
 * @author YKB Swift Team
 * @version 3.0.0
 */
@Configuration
public class LogbackEmailAppenderConfig {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(LogbackEmailAppenderConfig.class);

    private final ApplicationContext applicationContext;
    private final ObjectProvider<MeterRegistry> meterRegistryProvider;

    public LogbackEmailAppenderConfig(ApplicationContext applicationContext, ObjectProvider<MeterRegistry> meterRegistryProvider) {
        this.applicationContext = applicationContext;
        this.meterRegistryProvider = meterRegistryProvider;
    }

    @EventListener(ApplicationReadyEvent.class)
    @Order(0)
    public void configureEmailAppender() {
        log.info("Initializing Email Error Appender configuration...");

        try {
            LoggerContext loggerContext = getLoggerContext();
            if (loggerContext == null) return;

            List<EmailErrorAppender> configuredAppenders = findAndConfigureAppenders(loggerContext);

            if (!configuredAppenders.isEmpty()) {
                configureGlobalSettings();
                logConfigurationSummary(configuredAppenders);
            }

        } catch (Exception e) {
            log.warn("Failed to configure EmailErrorAppender: {}", e.getMessage());
        }
    }

    private void configureGlobalSettings() {
        Environment env = applicationContext.getEnvironment();

        // 1. Queue Capacity
        Integer queueCapacity = env.getProperty("logging.email.queue-capacity", Integer.class);
        if (queueCapacity != null) {
            EmailErrorAppender.setQueueCapacity(queueCapacity);
        }

        // 2. Circuit Breaker Threshold
        Integer cbThreshold = env.getProperty("logging.email.circuit-breaker.threshold", Integer.class);
        if (cbThreshold != null) {
            EmailErrorAppender.setCircuitBreakerThreshold(cbThreshold);
        }

        // 3. Deep Link URL
        String deepLinkUrl = env.getProperty("logging.email.deep-link-base-url");
        if (deepLinkUrl != null) {
            EmailErrorAppender.setDeepLinkBaseUrl(deepLinkUrl);
        }

        // 4. Metrics
        MeterRegistry registry = meterRegistryProvider.getIfAvailable();
        if (registry != null) {
            EmailErrorAppender.setMeterRegistry(registry);
            log.info("EmailErrorAppender metrics enabled.");
        }
    }

    private LoggerContext getLoggerContext() {
        var factory = LoggerFactory.getILoggerFactory();
        return (factory instanceof LoggerContext) ? (LoggerContext) factory : null;
    }

    private List<EmailErrorAppender> findAndConfigureAppenders(LoggerContext loggerContext) {
        List<EmailErrorAppender> configuredAppenders = new ArrayList<>();
        Logger rootLogger = loggerContext.getLogger(org.slf4j.Logger.ROOT_LOGGER_NAME);

        configureAppendersForLogger(rootLogger, configuredAppenders);

        for (Logger logger : loggerContext.getLoggerList()) {
            configureAppendersForLogger(logger, configuredAppenders);
        }
        return configuredAppenders;
    }

    private void configureAppendersForLogger(Logger logger, List<EmailErrorAppender> list) {
        Iterator<Appender<ILoggingEvent>> it = logger.iteratorForAppenders();
        while (it.hasNext()) {
            Appender<ILoggingEvent> appender = it.next();
            if (appender instanceof EmailErrorAppender emailAppender && !list.contains(emailAppender)) {
                emailAppender.setApplicationContext(applicationContext);
                list.add(emailAppender);
            }
        }
    }

    private void logConfigurationSummary(List<EmailErrorAppender> appenders) {
        Environment env = applicationContext.getEnvironment();
        log.info("═══════════════════════════════════════════════════════════════");
        log.info("  Email Error Notification System - ACTIVE (v3.0.0)");
        log.info("═══════════════════════════════════════════════════════════════");
        log.info("  Appenders found : {}", appenders.size());
        log.info("  Queue Capacity  : {}", env.getProperty("logging.email.queue-capacity", "100 (default)"));
        log.info("  Circuit Breaker : {}", env.getProperty("logging.email.circuit-breaker.threshold", "10 (default)"));
        
        String recipient = env.getProperty("error.email.recipient");
        if (recipient != null) {
            log.info("✅ Recipient       : {}", recipient);
        } else {
            log.warn("⚠️  Recipient       : NOT CONFIGURED (Emails disabled)");
        }
        log.info("═══════════════════════════════════════════════════════════════");
    }
}
