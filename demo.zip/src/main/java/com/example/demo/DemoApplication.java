package com.example.demo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

@SpringBootApplication
@RestController
@Slf4j
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @GetMapping("/hello")
    public String hello() {
        try {
            int randomNum = new Random().nextInt(100);
            if (randomNum % 2 == 0) {
                throw new RuntimeException("Random number is even: " + randomNum);
            }
            return "Hello World! " + randomNum;
        } catch (Exception e) {
            log.error("Error occurred: ", e);
            throw new RuntimeException(e);
        }
    }

}
