package com.example.demo;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.StackTraceElementProxy;
import ch.qos.logback.core.AppenderBase;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Custom Logback appender that intercepts ERROR level logs and sends them via email.
 *
 * <p><b>Features:</b>
 * <ul>
 *   <li><b>Async & Non-Blocking:</b> Zero latency on main thread.</li>
 *   <li><b>Observability:</b> Micrometer metrics for sent/dropped emails.</li>
 *   <li><b>Resilience:</b> Circuit Breaker & Rate Limiting.</li>
 *   <li><b>HTML Formatting:</b> Rich email content with color coding.</li>
 * </ul>
 *
 * @author YKB Swift Team
 * @version 3.0.0
 */
@Component
public class EmailErrorAppender extends AppenderBase<ILoggingEvent> implements ApplicationContextAware {

    private static final Logger INTERNAL_LOGGER = LoggerFactory.getLogger(EmailErrorAppender.class);
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // Configuration Keys
    private static final String PROPERTY_RECIPIENT = "error.email.recipient";
    private static final String ENV_RECIPIENT = "ERROR_EMAIL_RECIPIENT";
    private static final String PROPERTY_ENABLED = "error.email.enabled";
    private static final String ENV_ENABLED = "ERROR_EMAIL_ENABLED";

    // Exclusions
    private static final Set<String> EXCLUDED_LOGGER_PREFIXES = Set.of(
            "com.ykb.cosmos.swift.moneytransfer.external.email",
            "com.ykb.cosmos.swift.moneytransfer.logging",
            "org.springframework.mail",
            "com.sun.mail",
            "javax.mail"
    );

    // State
    private static volatile ApplicationContext applicationContext;
    private static volatile EmailService cachedEmailService;
    private static volatile boolean beanLookupFailed = false;
    private static volatile String cachedRecipientEmail;
    private static volatile boolean recipientEvaluated = false;

    // Configurable Properties (with defaults)
    private static int queueCapacity = 100;
    private static int circuitBreakerThreshold = 10;
    private static String deepLinkBaseUrl = null; // e.g., "https://kibana.company.com/app/discover?q="

    // Metrics
    private static MeterRegistry meterRegistry;
    private static Counter metricSent;
    private static Counter metricDropped;
    private static Counter metricError;

    // Executor
    private static ExecutorService emailExecutor = createEmailExecutor(queueCapacity);

    // Circuit Breaker
    private static final AtomicReference<CircuitBreakerState> CIRCUIT_BREAKER_STATE =
            new AtomicReference<>(CircuitBreakerState.closed());
    private static final long CIRCUIT_BREAKER_RESET_TIME_MS = 300_000L; // 5 minutes

    // Rate Limiting
    private static final AtomicLong LAST_EMAIL_TIME = new AtomicLong(0);
    private static long minEmailIntervalMs = 1000L; // Not final to allow testing

    // Limits
    private static final int MAX_STACK_TRACE_DEPTH = 50; // Reduced for email readability

    /**
     * Re-creates the executor if the queue capacity changes.
     */
    private static synchronized void updateExecutor(int newCapacity) {
        if (queueCapacity != newCapacity) {
            queueCapacity = newCapacity;
            if (emailExecutor != null && !emailExecutor.isShutdown()) {
                emailExecutor.shutdown(); // Graceful shutdown of old pool
            }
            emailExecutor = createEmailExecutor(newCapacity);
            logInternal("Updated email executor queue capacity to: " + newCapacity);
        }
    }

    private static ExecutorService createEmailExecutor(int capacity) {
        ThreadFactory threadFactory = new ThreadFactory() {
            private final AtomicInteger counter = new AtomicInteger(0);
            @Override
            public Thread newThread(@NonNull Runnable r) {
                Thread thread = new Thread(r, "error-email-sender-" + counter.incrementAndGet());
                thread.setDaemon(true);
                thread.setPriority(Thread.MIN_PRIORITY);
                return thread;
            }
        };

        return new ThreadPoolExecutor(
                1, 3, 60L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(capacity),
                threadFactory,
                new ThreadPoolExecutor.DiscardOldestPolicy()
        );
    }

    @Override
    protected void append(ILoggingEvent event) {
        if (event == null || event.getLevel() != Level.ERROR) return;
        if (!isEmailNotificationEnabled()) return;
        if (isExcludedLogger(event.getLoggerName())) return;
        if (isCircuitBreakerOpen()) return;
        if (!tryAcquireRateLimit()) return;

        String recipient = getRecipientEmail();
        if (recipient == null) return;

        EmailService emailService = getEmailServiceCached();
        if (emailService == null) return;

        submitEmailTask(emailService, recipient, event);
    }

    private void submitEmailTask(EmailService emailService, String recipient, ILoggingEvent event) {
        try {
            // 1. Fast Copy (Zero Latency on Main Thread)
            event.prepareForDeferredProcessing();

            ExecutorService executor = emailExecutor;
            if (executor != null && !executor.isShutdown()) {
                executor.submit(() -> {
                    // 2. Heavy Lifting (Background Thread)
                    try {
                        String subject = buildSubject(event);
                        String body = buildHtmlBody(event);
                        sendEmailSafely(emailService, recipient, subject, body);
                    } catch (Exception e) {
                        logInternal("Error building/sending email: " + e.getMessage());
                    }
                });
            } else {
                incrementMetric(metricDropped);
            }
        } catch (RejectedExecutionException e) {
            incrementMetric(metricDropped);
            logInternal("Email queue full. Dropping log.");
        } catch (Exception e) {
            incrementMetric(metricError);
        }
    }

    private static void sendEmailSafely(EmailService emailService, String recipient, String subject, String body) {
        try {
            emailService.sendEmail(recipient, subject, body);
            incrementMetric(metricSent);

            CircuitBreakerState currentState = CIRCUIT_BREAKER_STATE.get();
            if (currentState.failureCount() > 0) {
                CIRCUIT_BREAKER_STATE.set(CircuitBreakerState.closed());
            }
        } catch (Exception e) {
            incrementMetric(metricError);
            handleEmailFailure(e);
        }
    }

    // --- HTML Formatting ---

    private static String buildHtmlBody(ILoggingEvent event) {
        StringBuilder sb = new StringBuilder(4096);
        String color = "#D32F2F"; // Red for Error

        sb.append("<html><body style='font-family: Arial, sans-serif; color: #333;'>");
        
        // Header
        sb.append("<div style='background-color: ").append(color).append("; color: white; padding: 15px; border-radius: 5px 5px 0 0;'>");
        sb.append("<h2 style='margin:0;'>🚨 Error Notification</h2>");
        sb.append("</div>");

        // Summary Table
        sb.append("<div style='border: 1px solid #ddd; padding: 15px; background-color: #f9f9f9;'>");
        sb.append("<table style='width:100%; border-collapse: collapse;'>");
        appendRow(sb, "Application", System.getProperty("spring.application.name", "Unknown"));
        appendRow(sb, "Timestamp", LocalDateTime.now().format(FORMATTER));
        appendRow(sb, "Logger", escapeHtml(event.getLoggerName()));
        appendRow(sb, "Thread", escapeHtml(event.getThreadName()));
        
        // Deep Link
        if (deepLinkBaseUrl != null && !deepLinkBaseUrl.isBlank()) {
            String traceId = event.getMDCPropertyMap().get("traceId");
            if (traceId != null) {
                String link = deepLinkBaseUrl + traceId;
                sb.append("<tr><td style='padding: 8px; font-weight: bold;'>Logs:</td>");
                sb.append("<td style='padding: 8px;'><a href='").append(link).append("'>View in Log System</a></td></tr>");
            }
        }
        sb.append("</table></div>");

        // Message
        sb.append("<div style='margin-top: 20px;'>");
        sb.append("<h3 style='border-bottom: 2px solid ").append(color).append(";'>Error Message</h3>");
        sb.append("<pre style='background: #fff0f0; padding: 10px; border-left: 5px solid ").append(color).append("; white-space: pre-wrap;'>");
        sb.append(escapeHtml(event.getFormattedMessage()));
        sb.append("</pre></div>");

        // MDC
        Map<String, String> mdc = event.getMDCPropertyMap();
        if (mdc != null && !mdc.isEmpty()) {
            sb.append("<div style='margin-top: 20px;'><h3>Context (MDC)</h3>");
            sb.append("<ul>");
            mdc.forEach((k, v) -> sb.append("<li><b>").append(escapeHtml(k)).append(":</b> ").append(escapeHtml(v)).append("</li>"));
            sb.append("</ul></div>");
        }

        // Stack Trace
        if (event.getThrowableProxy() != null) {
            sb.append("<div style='margin-top: 20px;'><h3>Stack Trace</h3>");
            sb.append("<div style='background: #333; color: #eee; padding: 10px; overflow-x: auto; font-size: 12px; font-family: monospace;'>");
            appendThrowableHtml(sb, event.getThrowableProxy(), 0);
            sb.append("</div></div>");
        }

        sb.append("<div style='margin-top: 20px; font-size: 10px; color: #999; text-align: center;'>");
        sb.append("Generated by EmailErrorAppender v3.0.0</div>");
        sb.append("</body></html>");

        return sb.toString();
    }

    private static void appendRow(StringBuilder sb, String label, String value) {
        sb.append("<tr>");
        sb.append("<td style='padding: 5px; font-weight: bold; width: 120px;'>").append(label).append(":</td>");
        sb.append("<td style='padding: 5px;'>").append(value).append("</td>");
        sb.append("</tr>");
    }

    private static void appendThrowableHtml(StringBuilder sb, IThrowableProxy proxy, int depth) {
        if (proxy == null || depth > 10) return;

        if (depth > 0) sb.append("<br/>Caused by: ");
        sb.append("<b>").append(escapeHtml(proxy.getClassName())).append("</b>: ").append(escapeHtml(proxy.getMessage()));
        
        StackTraceElementProxy[] trace = proxy.getStackTraceElementProxyArray();
        if (trace != null) {
            int limit = Math.min(trace.length, MAX_STACK_TRACE_DEPTH);
            for (int i = 0; i < limit; i++) {
                sb.append("<br/>&nbsp;&nbsp;at ").append(escapeHtml(trace[i].getSTEAsString()));
            }
            if (trace.length > limit) {
                sb.append("<br/>&nbsp;&nbsp;... ").append(trace.length - limit).append(" more");
            }
        }

        if (proxy.getCause() != null) {
            appendThrowableHtml(sb, proxy.getCause(), depth + 1);
        }
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    // --- Configuration Setters (Called by Config Class) ---

    public static void setQueueCapacity(int capacity) {
        if (capacity > 0) updateExecutor(capacity);
    }

    public static void setCircuitBreakerThreshold(int threshold) {
        if (threshold > 0) circuitBreakerThreshold = threshold;
    }

    public static void setDeepLinkBaseUrl(String url) {
        deepLinkBaseUrl = url;
    }

    public static void setMeterRegistry(MeterRegistry registry) {
        meterRegistry = registry;
        if (registry != null) {
            metricSent = Counter.builder("email_appender_sent_total").description("Emails successfully sent").register(registry);
            metricDropped = Counter.builder("email_appender_dropped_total").description("Emails dropped due to queue full").register(registry);
            metricError = Counter.builder("email_appender_error_total").description("Errors during email processing").register(registry);
        }
    }
    
    public static void setRateLimitInterval(long ms) {
        minEmailIntervalMs = ms;
    }

    private static void incrementMetric(Counter counter) {
        if (counter != null) counter.increment();
    }

    // --- Existing Helper Methods (Simplified) ---

    private static boolean isEmailNotificationEnabled() {
        String enabled = System.getProperty(PROPERTY_ENABLED);
        if (enabled == null) enabled = System.getenv(ENV_ENABLED);
        if (enabled == null && applicationContext != null) {
            enabled = applicationContext.getEnvironment().getProperty(PROPERTY_ENABLED);
        }
        return enabled == null || !"false".equalsIgnoreCase(enabled.trim());
    }

    private static boolean isExcludedLogger(String loggerName) {
        if (loggerName == null) return false;
        for (String prefix : EXCLUDED_LOGGER_PREFIXES) {
            if (loggerName.startsWith(prefix)) return true;
        }
        return false;
    }

    private static boolean isCircuitBreakerOpen() {
        CircuitBreakerState state = CIRCUIT_BREAKER_STATE.get();
        if (!state.isOpen()) return false;
        long now = System.currentTimeMillis();
        if (now - state.openedAt() > CIRCUIT_BREAKER_RESET_TIME_MS) {
            CircuitBreakerState newState = CircuitBreakerState.closed();
            if (CIRCUIT_BREAKER_STATE.compareAndSet(state, newState)) {
                logInternal("Circuit breaker reset.");
            }
            return false;
        }
        return true;
    }

    private static boolean tryAcquireRateLimit() {
        long now = System.currentTimeMillis();
        long last;
        do {
            last = LAST_EMAIL_TIME.get();
            if (now - last < minEmailIntervalMs) return false;
        } while (!LAST_EMAIL_TIME.compareAndSet(last, now));
        return true;
    }

    private static String getRecipientEmail() {
        if (recipientEvaluated) return cachedRecipientEmail;
        synchronized (EmailErrorAppender.class) {
            if (!recipientEvaluated) {
                String recipient = System.getProperty(PROPERTY_RECIPIENT);
                if (recipient == null) recipient = System.getenv(ENV_RECIPIENT);
                if (recipient == null && applicationContext != null) {
                    recipient = applicationContext.getEnvironment().getProperty(PROPERTY_RECIPIENT);
                }
                cachedRecipientEmail = (recipient != null && !recipient.isBlank()) ? recipient.trim() : null;
                if (cachedRecipientEmail == null) logInternal("WARNING: Recipient not configured.");
                recipientEvaluated = true;
            }
        }
        return cachedRecipientEmail;
    }

    private static EmailService getEmailServiceCached() {
        if (cachedEmailService != null) return cachedEmailService;
        if (beanLookupFailed || applicationContext == null) return null;
        synchronized (EmailErrorAppender.class) {
            if (cachedEmailService != null) return cachedEmailService;
            try {
                cachedEmailService = applicationContext.getBean(EmailService.class);
                return cachedEmailService;
            } catch (Exception e) {
                beanLookupFailed = true;
                return null;
            }
        }
    }

    private static void handleEmailFailure(Exception e) {
        CircuitBreakerState currentState;
        CircuitBreakerState newState;
        do {
            currentState = CIRCUIT_BREAKER_STATE.get();
            int newFailureCount = currentState.failureCount() + 1;
            if (newFailureCount >= circuitBreakerThreshold) {
                newState = CircuitBreakerState.open(System.currentTimeMillis(), newFailureCount);
                logInternal("Circuit breaker OPENED.");
            } else {
                newState = CircuitBreakerState.withFailures(newFailureCount);
            }
        } while (!CIRCUIT_BREAKER_STATE.compareAndSet(currentState, newState));
    }

    private static String buildSubject(ILoggingEvent event) {
        String className = extractSimpleClassName(event.getLoggerName());
        String exceptionInfo = "";
        if (event.getThrowableProxy() != null) {
            exceptionInfo = " - " + extractSimpleClassName(event.getThrowableProxy().getClassName());
        }
        return String.format("[ERROR] %s%s", className, exceptionInfo);
    }

    private static String extractSimpleClassName(String fullyQualifiedName) {
        if (fullyQualifiedName == null) return "Unknown";
        int lastDot = fullyQualifiedName.lastIndexOf('.');
        return (lastDot > 0) ? fullyQualifiedName.substring(lastDot + 1) : fullyQualifiedName;
    }

    private static void logInternal(String message) {
        System.out.println("[EmailErrorAppender] " + LocalDateTime.now().format(FORMATTER) + " - " + message);
    }

    @Override
    public void setApplicationContext(@NonNull ApplicationContext context) {
        applicationContext = context;
        cachedEmailService = null;
        beanLookupFailed = false;
        cachedRecipientEmail = null;
        recipientEvaluated = false;
    }

    @Override
    public void stop() {
        super.stop();
        if (emailExecutor != null) emailExecutor.shutdownNow();
    }

    public static void resetForTesting() {
        applicationContext = null;
        cachedEmailService = null;
        beanLookupFailed = false;
        cachedRecipientEmail = null;
        recipientEvaluated = false;
        CIRCUIT_BREAKER_STATE.set(CircuitBreakerState.closed());
        LAST_EMAIL_TIME.set(0);
        minEmailIntervalMs = 1000L; // Reset to default
        meterRegistry = null;
        if (emailExecutor == null || emailExecutor.isShutdown()) {
            emailExecutor = createEmailExecutor(queueCapacity);
        }
    }

    private record CircuitBreakerState(boolean isOpen, long openedAt, int failureCount) {
        static CircuitBreakerState closed() { return new CircuitBreakerState(false, 0, 0); }
        static CircuitBreakerState open(long openedAt, int failureCount) { return new CircuitBreakerState(true, openedAt, failureCount); }
        static CircuitBreakerState withFailures(int failureCount) { return new CircuitBreakerState(false, 0, failureCount); }
    }
}
