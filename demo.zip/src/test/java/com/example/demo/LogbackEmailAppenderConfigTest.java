package com.example.demo;

import ch.qos.logback.classic.LoggerContext;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LogbackEmailAppenderConfigTest {

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private ObjectProvider<MeterRegistry> meterRegistryProvider;
    
    @Mock
    private Environment environment;

    private LogbackEmailAppenderConfig config;

    @BeforeEach
    void setUp() {
        config = new LogbackEmailAppenderConfig(applicationContext, meterRegistryProvider);
        lenient().when(applicationContext.getEnvironment()).thenReturn(environment);
    }

    @Test
    void configureEmailAppender_ShouldConfigureAppender_WhenFound() {
        assertDoesNotThrow(() -> config.configureEmailAppender());
    }
    
    @Test
    void configureEmailAppender_ShouldReadProperties() {
        // Arrange
        // Bu property'lerin okunup okunmadığını test etmek için LoggerContext'in dolu gelmesi lazım.
        // Ancak statik LoggerFactory mocklamak zor olduğu için lenient kullanıyoruz.
        // Bu test aslında konfigürasyonun hata vermeden çalıştığını doğruluyor.
        lenient().when(environment.getProperty("logging.email.queue-capacity", Integer.class)).thenReturn(500);
        lenient().when(environment.getProperty("logging.email.circuit-breaker.threshold", Integer.class)).thenReturn(20);
        lenient().when(environment.getProperty("logging.email.deep-link-base-url")).thenReturn("http://test.com/");
        
        // Act
        config.configureEmailAppender();
        
        // Assert
        // Hata fırlatmaması yeterli
    }
}
