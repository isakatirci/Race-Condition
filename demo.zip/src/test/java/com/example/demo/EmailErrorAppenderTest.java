package com.example.demo;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.ThrowableProxy;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmailErrorAppenderTest {

    private EmailErrorAppender appender;

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private Environment environment;

    @Mock
    private EmailService emailService;

    @Mock
    private ILoggingEvent loggingEvent;

    private MeterRegistry meterRegistry;

    @BeforeEach
    void setUp() {
        EmailErrorAppender.resetForTesting();
        meterRegistry = new SimpleMeterRegistry();
        
        appender = new EmailErrorAppender();
        appender.setApplicationContext(applicationContext);
        EmailErrorAppender.setMeterRegistry(meterRegistry);
        appender.start();

        // Varsayılan mock davranışları
        lenient().when(applicationContext.getEnvironment()).thenReturn(environment);
        lenient().when(environment.getProperty("error.email.recipient")).thenReturn("test@example.com");
        lenient().when(environment.getProperty("error.email.enabled")).thenReturn("true");
        lenient().when(applicationContext.getBean(EmailService.class)).thenReturn(emailService);
    }

    @AfterEach
    void tearDown() {
        appender.stop();
        EmailErrorAppender.resetForTesting();
    }

    @Test
    void append_ShouldSendEmail_WhenEventIsError() {
        // Arrange
        when(loggingEvent.getLevel()).thenReturn(Level.ERROR);
        when(loggingEvent.getLoggerName()).thenReturn("com.example.TestLogger");
        when(loggingEvent.getFormattedMessage()).thenReturn("Test Error Message");
        when(loggingEvent.getThreadName()).thenReturn("main");
        
        // Act
        appender.append(loggingEvent);

        // Assert
        verify(emailService, timeout(2000)).sendEmail(
                eq("test@example.com"), 
                contains("TestLogger"), // Subject check
                argThat(body -> body.contains("Test Error Message") && body.contains("<html>")) // HTML Body check
        );
        
        assertEquals(1.0, meterRegistry.get("email_appender_sent_total").counter().count());
    }

    @Test
    void append_ShouldNotSendEmail_WhenLevelIsNotError() {
        // Arrange
        when(loggingEvent.getLevel()).thenReturn(Level.INFO);

        // Act
        appender.append(loggingEvent);

        // Assert
        verify(emailService, never()).sendEmail(anyString(), anyString(), anyString());
    }

    @Test
    void append_ShouldIncludeExceptionInfo_WhenThrowablePresent() {
        // Arrange
        when(loggingEvent.getLevel()).thenReturn(Level.ERROR);
        when(loggingEvent.getLoggerName()).thenReturn("com.example.TestLogger");
        when(loggingEvent.getFormattedMessage()).thenReturn("Error with exception");
        when(loggingEvent.getThreadName()).thenReturn("main");
        
        IThrowableProxy throwableProxy = new ThrowableProxy(new RuntimeException("Test Exception"));
        when(loggingEvent.getThrowableProxy()).thenReturn(throwableProxy);

        // Act
        appender.append(loggingEvent);

        // Assert
        verify(emailService, timeout(2000)).sendEmail(
                anyString(), 
                contains("RuntimeException"), 
                argThat(body -> body.contains("Test Exception") && body.contains("Stack Trace"))
        );
    }

    @Test
    void append_ShouldRespectRateLimit() {
        // Arrange
        when(loggingEvent.getLevel()).thenReturn(Level.ERROR);
        when(loggingEvent.getLoggerName()).thenReturn("com.example.TestLogger");
        when(loggingEvent.getFormattedMessage()).thenReturn("Rate Limit Test");
        when(loggingEvent.getThreadName()).thenReturn("main");

        // Act
        // Hızlıca iki kez çağır
        appender.append(loggingEvent);
        appender.append(loggingEvent);

        // Assert
        // Sadece bir kez gönderilmeli (Rate limit: 1 sn)
        verify(emailService, timeout(2000).times(1)).sendEmail(anyString(), anyString(), anyString());
    }

    @Test
    void append_ShouldNotSend_WhenRecipientNotConfigured() {
        // Arrange
        when(environment.getProperty("error.email.recipient")).thenReturn(null);
        System.clearProperty("error.email.recipient"); 
        
        when(loggingEvent.getLevel()).thenReturn(Level.ERROR);

        // Act
        appender.append(loggingEvent);

        // Assert
        verify(emailService, never()).sendEmail(anyString(), anyString(), anyString());
    }
    
    @Test
    void append_ShouldIncludeMDC_WhenPresent() {
        // Arrange
        when(loggingEvent.getLevel()).thenReturn(Level.ERROR);
        when(loggingEvent.getLoggerName()).thenReturn("com.example.TestLogger");
        when(loggingEvent.getFormattedMessage()).thenReturn("MDC Test");
        when(loggingEvent.getThreadName()).thenReturn("main");
        when(loggingEvent.getMDCPropertyMap()).thenReturn(Map.of("userId", "12345"));

        // Act
        appender.append(loggingEvent);

        // Assert
        verify(emailService, timeout(2000)).sendEmail(
                anyString(), 
                anyString(), 
                argThat(body -> body.contains("userId") && body.contains("12345"))
        );
    }

    @Test
    void append_ShouldIncludeDeepLink_WhenConfigured() {
        // Arrange
        EmailErrorAppender.setDeepLinkBaseUrl("http://logs.com/trace/");
        
        when(loggingEvent.getLevel()).thenReturn(Level.ERROR);
        when(loggingEvent.getLoggerName()).thenReturn("com.example.TestLogger");
        when(loggingEvent.getFormattedMessage()).thenReturn("Deep Link Test");
        when(loggingEvent.getThreadName()).thenReturn("main");
        when(loggingEvent.getMDCPropertyMap()).thenReturn(Map.of("traceId", "abc-123"));

        // Act
        appender.append(loggingEvent);

        // Assert
        verify(emailService, timeout(2000)).sendEmail(
                anyString(), 
                anyString(), 
                argThat(body -> body.contains("http://logs.com/trace/abc-123"))
        );
    }

    @Test
    void append_ShouldIncrementErrorMetric_WhenEmailServiceFails() {
        // Arrange
        when(loggingEvent.getLevel()).thenReturn(Level.ERROR);
        when(loggingEvent.getLoggerName()).thenReturn("com.example.TestLogger");
        when(loggingEvent.getFormattedMessage()).thenReturn("Fail Test");
        when(loggingEvent.getThreadName()).thenReturn("main");
        
        doThrow(new RuntimeException("SMTP Error")).when(emailService).sendEmail(anyString(), anyString(), anyString());

        // Act
        appender.append(loggingEvent);

        // Assert
        verify(emailService, timeout(2000)).sendEmail(anyString(), anyString(), anyString());
        
        // Wait for async execution to finish updating metrics
        try { Thread.sleep(100); } catch (InterruptedException e) {}
        
        assertEquals(1.0, meterRegistry.get("email_appender_error_total").counter().count());
    }
    
    @Test
    void append_ShouldDropEmail_WhenQueueIsFull() {
        // Arrange
        // Rate limit'i devre dışı bırak (0 ms)
        EmailErrorAppender.setRateLimitInterval(0);
        
        when(loggingEvent.getLevel()).thenReturn(Level.ERROR);
        when(loggingEvent.getLoggerName()).thenReturn("com.example.TestLogger");
        // getFormattedMessage ve getThreadName kullanılmıyor çünkü executor kapalı
        
        // Executor'ı shutdown ederek kuyruk doluluğu (rejected execution) simüle edelim
        appender.stop(); 
        
        // Act
        appender.append(loggingEvent); 

        // Assert
        assertEquals(1.0, meterRegistry.get("email_appender_dropped_total").counter().count());
    }
}
