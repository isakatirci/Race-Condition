package com.example.demo;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

@ExtendWith(MockitoExtension.class)
class EmailServiceTest {

    @InjectMocks
    private EmailService emailService;

    @Test
    void sendEmail_ShouldLogMessage_WhenCalled() {
        // EmailService sadece loglama yaptığı için exception fırlatmadığını doğrulamak yeterlidir.
        // Gerçek log kontrolü için LogCaptor kullanılabilir ama basitlik adına bu yeterlidir.
        assertDoesNotThrow(() -> 
            emailService.sendEmail("test@example.com", "Test Subject", "Test Body")
        );
    }
}
